#Let's build robot barista!!!


print("Hello Welcome to XDroid coffee")

name = input("what is your name?\n")


if name == "david" or name == "rachel":
    evil_status = input("Are you Evil?\n")
    good_deeds = int(input("How many good deeds have you done today?\n"))
    if evil_status == "yes" and good_deeds  < 4:

        
     print("You're not welcome here Evil person!! Get OUT!!")
     exit()
    else:
        print("oh, so you're one of those good davids come on in!!")
 
else:
    print("hello " + name + " thankyou for coming in today.\n\n\n ")    




print("hello " + name + " thankyou for coming in today.\n\n\n ")


menu = "Black Coffee, Espresso, latte, cappucino, frappuccino\n"

print(name + ", what would you like from our menu today? here is what we are serving.\n" + menu)


order = input()


price = 8


quantity = input("how many coffees would you like?\n")



#Set the price for coffee

if order == "frappuccino":
    price = 13
elif order == "black coffee":
    price = 3
elif order == "espresso":
    price = 5
elif order == "latte":
    price = 9
elif order == "cappucino":
    price = 10

total = price * int(quantity)


print("Thank you. Your total is: £" + str(total))



print("Sounds good " + name + ", we'll have your " + quantity + " " + order + " ready for you in a moment ")









